Another work in progress.
